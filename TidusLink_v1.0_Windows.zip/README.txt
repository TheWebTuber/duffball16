TIDUSLINK — VERSION 1.0
=======================

WHAT IT DOES
------------
TidusLink is a small local Bedrock console-server relay. It makes a compatible
remote Bedrock/Geyser server appear as a temporary LAN game to compatible
Bedrock console clients on the same trusted home network.

TidusLink is free, ad-free, open source and intended as a non-commercial
community utility. It is not a game server host and does not host, control or
moderate the remote servers users choose.

MAIN FEATURES
-------------
- Bedrock relay only.
- Any hostname/IP plus any valid UDP server port.
- Custom LAN display name and subtitle.
- No account.
- No advertisements.
- No analytics or global usage telemetry.
- No saved custom-server history.
- Remote public server status/player-count check.
- Local active relay-session count for this running copy.
- Stop and reconnect without restarting TidusLink.
- Featured Duffball16 SMP card with copyable server details.

DUFFBALL16 SMP
--------------
Name:    Duffball16 SMP
Tagline: Home of the Duffinians
IP:      mc.duffball16.com
Port:    19133

The Duffball16 card does NOT auto-connect. Copy its IP and port into the normal
custom-server fields, choose the LAN name/subtitle you want, then press START
LAN LINK. This keeps the featured server using the exact same connection path
as every other server.

HOW TO USE ON WINDOWS
---------------------
1. Put the Windows PC/laptop and compatible Bedrock console on the same trusted home network.
2. Make sure no other local relay/proxy utility is already using UDP 19132.
3. Run TidusLink-v1.0-Windows.exe.
4. TidusLink opens its local control page in your default browser.
5. If Windows Firewall asks, allow access on PRIVATE/TRUSTED networks only.
6. Paste/type a compatible Bedrock/Geyser server address and UDP port.
7. Optionally choose a LAN display name and subtitle.
8. Press START LAN LINK and keep TidusLink open.
9. On the console, open the Bedrock game and look under Friends / LAN games.
10. Select the advertised LAN entry and join.
11. When finished, press STOP CONNECTION and close TidusLink.

IF THE LAN ENTRY DOES NOT APPEAR
--------------------------------
- Confirm the PC and console are on the same home LAN.
- Restart the game on the console.
- Check Windows Firewall private-network permission.
- Close other local Bedrock relay/proxy utilities.
- Check that the router/access point does not isolate wireless clients from each other.
- TidusLink uses local UDP port 19132 for LAN discovery.

PRIVACY
-------
The official build has no advertising SDK, account system or global usage
telemetry. It does not intentionally upload custom server entries, custom LAN
names or local session counts to a TidusLink-operated service.

TidusLink is a networking utility. A connection necessarily sends traffic to
the remote server selected by the user. That server and other network/platform
providers can have their own logging, privacy and security practices.

PLAYER INFORMATION
------------------
TidusLink can show the public current/max player count reported by a remote
server and the number of active local relay sessions using THIS running copy.
It does not display player usernames and does not intentionally inspect player
identity packets.

OPEN SOURCE
-----------
Source code is distributed separately in the TidusLink v1.0 Source package.
TidusLink is licensed under the MIT License. See LICENSE.txt and CREDITS.txt.

LEGAL / SECURITY NOTICE
-----------------------
TidusLink is provided AS IS and WITHOUT WARRANTY. Use it only on networks and
servers you are authorized to access. Users are responsible for the servers
they choose, firewall/network settings, account/device security, third-party
server content, backups, platform/server rules and applicable law.

A disclaimer cannot guarantee zero legal or security risk. See DISCLAIMER.txt
for the complete project notice.

TidusLink is an unofficial independent project and is not affiliated with,
endorsed by or sponsored by Mojang Studios or Microsoft.
