TIDUSLINK — VERSION 1.1
=======================

TidusLink is a free, ad-free, open-source local Bedrock LAN relay. It can make a
compatible remote Bedrock/Geyser server appear as a temporary LAN game to compatible
Bedrock console clients on the same trusted home network.

FEATURES
--------
- Any compatible Bedrock/Geyser hostname/IP and UDP port.
- Custom LAN display name and subtitle.
- No account, ads, analytics, global usage telemetry, or saved custom-server history.
- Remote public server status/player count.
- Local active relay-session count for this running copy.
- Featured Duffball16 SMP details: mc.duffball16.com : 19133.
- Optional collapsed Support the developer section for Portal Master Of Games.
- YouTube and PayPal support QR codes are built into the interface and work offline as images.

SUPPORT
-------
TidusLink is distributed free of charge and works fully without payment. The optional
support section links to Portal Master Of Games on YouTube and to an optional PayPal
donation page. Donations do not unlock features, remove limits, or change functionality.
External YouTube/PayPal links are governed by those services' own policies.

HOW THE LINK WORKS
------------------
TidusLink listens locally on UDP 19132 for Bedrock LAN discovery and relays a connected
console session to the remote server you select. Keep TidusLink running while connected.
Only use it on networks and servers you are authorized to access.

IF THE LAN ENTRY DOES NOT APPEAR
--------------------------------
- Confirm the computer and console are on the same trusted home LAN.
- Close any other local relay/proxy utility that is using UDP 19132.
- Restart the Bedrock game on the console.
- Check firewall permission for the private/trusted network.
- Check that the router/access point is not isolating Wi-Fi/LAN clients.

DUFFBALL16 SMP
--------------
Name:    Duffball16 SMP
Tagline: Home of the Duffinians
IP:      mc.duffball16.com
Port:    19133

The featured card only shows/copies the server details. Paste them into the normal
server fields, choose the LAN name/subtitle you want, and press START LAN LINK.

PRIVACY / LEGAL
---------------
TidusLink itself contains no advertising SDK, account system, or global usage telemetry.
Network traffic necessarily goes to the remote server selected by the user. See
DISCLAIMER.txt and LICENSE.txt. TidusLink is an unofficial independent project and is
not affiliated with, endorsed by, or sponsored by Mojang Studios or Microsoft.

WINDOWS QUICK START
-------------------
1. Extract the ZIP.
2. Put the Windows PC/laptop and console on the same trusted home network.
3. Run TidusLink-v1.1-Windows.exe.
4. The local TidusLink page should open in your browser.
5. If Windows Firewall asks, allow the app on PRIVATE/TRUSTED networks only.
6. Enter the Bedrock server address/port, set the LAN name if wanted, and press START LAN LINK.
7. On the console, open Bedrock and look under Friends / LAN games.
8. Keep TidusLink open until you finish.
