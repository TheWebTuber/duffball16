module tiduslink

go 1.23
