package main

import (
	"encoding/binary"
	"net"
	"strings"
	"testing"
	"time"
)

func fakePongFor(ping []byte, port int) []byte {
	desc := "MCPE;Remote Test;900;1.99.0;2;20;123456789;Remote subtitle;Survival;1;" +
		strconvItoa(port) + ";19133;"
	out := make([]byte, 35+len(desc))
	out[0] = 0x1c
	copy(out[1:9], ping[1:9])
	binary.BigEndian.PutUint64(out[9:17], 123456789)
	copy(out[17:33], raknetMagic)
	binary.BigEndian.PutUint16(out[33:35], uint16(len(desc)))
	copy(out[35:], desc)
	return out
}

func strconvItoa(n int) string {
	if n == 0 {
		return "0"
	}
	var b [20]byte
	i := len(b)
	for n > 0 {
		i--
		b[i] = byte('0' + n%10)
		n /= 10
	}
	return string(b[i:])
}

func TestBuildPongCustomNames(t *testing.T) {
	ping := buildPing()
	remote := fakePongFor(ping, 19140)
	info, err := parsePong(remote, "example.test", 19140)
	if err != nil {
		t.Fatal(err)
	}
	pong, err := buildPong(ping, info, "My SMP", "Friends only")
	if err != nil {
		t.Fatal(err)
	}
	parsed, err := parsePong(pong, "local", lanPort)
	if err != nil {
		t.Fatal(err)
	}
	if parsed.MOTD != "My SMP" {
		t.Fatalf("MOTD=%q", parsed.MOTD)
	}
	if parsed.SubMOTD != "Friends only" {
		t.Fatalf("SubMOTD=%q", parsed.SubMOTD)
	}
	if parsed.Protocol != "900" || parsed.Version != "1.99.0" {
		t.Fatalf("mirror failed: %+v", parsed)
	}
}

func TestProxyDiscoveryAndRelay(t *testing.T) {
	remote, err := net.ListenUDP("udp4", &net.UDPAddr{IP: net.ParseIP("127.0.0.1"), Port: 0})
	if err != nil {
		t.Fatal(err)
	}
	defer remote.Close()
	rport := remote.LocalAddr().(*net.UDPAddr).Port
	stop := make(chan struct{})
	go func() {
		buf := make([]byte, 65535)
		for {
			_ = remote.SetReadDeadline(time.Now().Add(200 * time.Millisecond))
			n, addr, err := remote.ReadFromUDP(buf)
			if err != nil {
				if ne, ok := err.(net.Error); ok && ne.Timeout() {
					select {
					case <-stop:
						return
					default:
						continue
					}
				}
				return
			}
			p := append([]byte(nil), buf[:n]...)
			if isDiscoveryPing(p) {
				_, _ = remote.WriteToUDP(fakePongFor(p, rport), addr)
			} else {
				echo := append([]byte("ECHO:"), p...)
				_, _ = remote.WriteToUDP(echo, addr)
			}
		}
	}()
	defer close(stop)

	p := &Proxy{sessions: make(map[string]*Session)}
	info, err := p.Start("127.0.0.1", rport, "Custom LAN", "Test subtitle")
	if err != nil {
		t.Fatal(err)
	}
	defer p.Stop()
	if info.MOTD != "Remote Test" {
		t.Fatalf("unexpected remote info: %+v", info)
	}

	client, err := net.DialUDP("udp4", nil, &net.UDPAddr{IP: net.ParseIP("127.0.0.1"), Port: lanPort})
	if err != nil {
		t.Fatal(err)
	}
	defer client.Close()
	_ = client.SetDeadline(time.Now().Add(2 * time.Second))

	ping := buildPing()
	if _, err := client.Write(ping); err != nil {
		t.Fatal(err)
	}
	buf := make([]byte, 4096)
	n, err := client.Read(buf)
	if err != nil {
		t.Fatal(err)
	}
	got, err := parsePong(buf[:n], "local", lanPort)
	if err != nil {
		t.Fatal(err)
	}
	if got.MOTD != "Custom LAN" || got.SubMOTD != "Test subtitle" {
		t.Fatalf("custom LAN advertisement failed: %+v", got)
	}

	payload := []byte{0x05, 0xaa, 0xbb, 0xcc}
	if _, err := client.Write(payload); err != nil {
		t.Fatal(err)
	}
	n, err = client.Read(buf)
	if err != nil {
		t.Fatal(err)
	}
	if string(buf[:n]) != "ECHO:"+string(payload) {
		t.Fatalf("relay mismatch: %q", string(buf[:n]))
	}

	st := p.Status()
	if running, _ := st["running"].(bool); !running {
		t.Fatal("proxy should be running")
	}
	if sessions, _ := st["sessions"].(int); sessions < 1 {
		t.Fatalf("expected session, got %#v", st)
	}
	if !strings.Contains(st["remote"].(string), "127.0.0.1") {
		t.Fatalf("unexpected status: %#v", st)
	}
}
